package Model;

public interface Observer {

    void notifyOb();

    void eventUpdate();

}
